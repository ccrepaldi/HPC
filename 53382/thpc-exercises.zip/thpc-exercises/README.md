# Tools for High Performance Computing
Exercise's and problem's solutions for the 53382 - Tools for High Performance Computing course.
Course period: Autumn 2015.
